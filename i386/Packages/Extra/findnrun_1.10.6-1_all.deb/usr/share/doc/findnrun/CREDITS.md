## Credits

**find-n-run desktop icon**

 * Icon Pack: Human-O2
 * Designer: http://schollidesign.deviantart.com
 * License: GNU/GPL
 * Download: http://findicons.com/icon/94185/old_zoom_original

**Translations**

 * French, 1.10.6, ASRI at Puppy Linux Forum
 * German, 1.10.6, L18L at Puppy Linux Forum
 * Italian, 1.10.6, xanad at Puppy Linux Forum
 * Spanish, 1.10.6, nilsonmorales@hotmail.com
 * Simplified Chinese, 1.10.6, icake@hotmail.com
 * Traditional Chinese, 1.10.6, icake@hotmail.com

