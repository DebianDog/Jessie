#define UTS_RELEASE "4.7.0-1-686-pae"
