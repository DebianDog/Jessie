/* This file is auto generated, version 1 */
/* SMP */
#define UTS_MACHINE "i386"
#define UTS_VERSION "#1 SMP Debian 4.7.8-1 (2016-10-19)"
#define LINUX_COMPILE_BY "debian-kernel"
#define LINUX_COMPILE_HOST "lists.debian.org"
#define LINUX_COMPILER "gcc version 5.4.1 20160904 (Debian 5.4.1-2) "
