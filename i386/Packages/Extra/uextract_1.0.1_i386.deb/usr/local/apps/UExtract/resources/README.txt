You can put here binaries and libraries, e.g. poweriso, unrar, ccrypt, etc.
