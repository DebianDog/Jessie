#!/bin/sh


killall gtkdialog --program=desktop_view_edit
desktop_view_edit
